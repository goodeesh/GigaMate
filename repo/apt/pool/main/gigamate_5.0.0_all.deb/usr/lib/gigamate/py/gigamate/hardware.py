"""GigaMate — Unified Hardware State & Settings Reapplication Layer.

Ensures that user settings saved in config.json are safely and reliably applied
to physical hardware across all lifecycle events:
- Machine boot / user login (via systemd gigamate.service)
- Wake from suspend / hibernate / hybrid sleep (via sleep_handler PrepareForSleep)
- GigaMate Center application launch / reopen
- GigaMate Tray daemon restart / reload
"""

import logging
import threading
import time
from typing import Any, Dict, Optional

from .config import (
    DEFAULT_CONFIG,
    effective_brightness_pct,
    effective_rgb_hex,
    is_rgb_enabled,
    load as load_config,
    profile_rgb_for,
    update_config,
)

logger = logging.getLogger(__name__)

# Reapplying hardware touches USB/ACPI/battery; serialize across the GUI thread
# (launch) and the sleep-listener thread (resume) to avoid concurrent writes.
_APPLY_LOCK = threading.Lock()


def apply_profile(
    profile_id: int,
    cfg: Optional[Dict[str, Any]] = None,
    sync_system: bool = True,
    acpi: Any = None,
) -> bool:
    """Apply a Gigabyte EC power profile, optionally syncing system power and profile RGB."""
    if cfg is None:
        cfg = load_config()

    applied = False
    try:
        from .acpi import AcpiController, FanProfile

        fp = FanProfile(int(profile_id))
        ctrl = acpi if acpi is not None else AcpiController()
        if ctrl.available:
            if ctrl.get_profile() == fp or ctrl.set_profile(fp):
                applied = True
    except Exception as exc:
        logger.warning("apply_profile: ACPI profile %r failed: %s", profile_id, exc)

    update_config(lambda c: {**c, "acpi_profile": int(profile_id)})

    sync_enabled = bool(
        cfg.get("sync_system_power", DEFAULT_CONFIG["sync_system_power"])
        or str(cfg.get("ac_profile_mode", "off")) == "switch"
    )
    if applied and sync_system and sync_enabled:
        try:
            from .system_power import sync_system_power

            sync_system_power(int(profile_id))
        except Exception as exc:
            logger.warning("apply_profile: system power sync failed: %s", exc)

    if cfg.get("profile_rgb_enabled", False) and is_rgb_enabled(cfg):
        hex_color = profile_rgb_for(cfg, int(profile_id))
        update_config(lambda c: {**c, "rgb_hex": hex_color})
        try:
            from . import protocol

            dev = protocol.get_keyboard()
            if dev is not None:
                pct = effective_brightness_pct(cfg)
                protocol.set_rgb(dev, hex_color, pct)
        except Exception as exc:
            logger.warning("apply_profile: keyboard RGB update failed: %s", exc)

    return applied


def apply_hardware_settings(
    cfg: Optional[Dict[str, Any]] = None,
    force_keyboard: bool = False,
) -> Dict[str, bool]:
    """Apply all persisted user settings to hardware with isolated error domains.

    If an individual subsystem fails (e.g. keyboard unplugged, or battery missing),
    the other subsystems continue to apply normally.

    Args:
        cfg: Configuration mapping; loaded from disk when omitted.
        force_keyboard: Apply keyboard lighting even when ``startup_apply`` is
            disabled (used to restore the backlight after resume).

    Returns:
        Dict[str, bool] indicating success/failure per subsystem:
        {"profile": bool, "battery": bool, "keyboard": bool}
    """
    with _APPLY_LOCK:
        return _apply_hardware_settings_locked(cfg, force_keyboard)


def _apply_hardware_settings_locked(
    cfg: Optional[Dict[str, Any]],
    force_keyboard: bool,
) -> Dict[str, bool]:
    if cfg is None:
        cfg = load_config()

    results = {
        "profile": False,
        "battery": False,
        "keyboard": False,
        "dgpu": False,
    }

    # ─────────────────────────────────────────────────────────────
    # 1. ACPI Fan/Power Profile & System Power Sync
    # ─────────────────────────────────────────────────────────────
    prof_val = cfg.get("acpi_profile")
    if prof_val is not None:
        from .acpi import AcpiController, FanProfile
        from .power_limits import discover_acpi_profiles

        discovered = {}
        try:
            discovered = discover_acpi_profiles()
        except Exception:
            discovered = {}

        if not discovered:
            logger.info("Hardware sync: skipping ACPI profile (no ACPI profiles discovered)")
        else:
            try:
                prof_val_i = int(prof_val)
            except (TypeError, ValueError):
                prof_val_i = None
            if prof_val_i is None or prof_val_i not in discovered:
                logger.warning("Hardware sync: ignoring acpi_profile %r (not in discovered profiles)", prof_val)
            else:
                # Parse the persisted profile id in its own error domain so a bad value
                # cannot suppress the system/GPU power sync below.
                fp: Optional[FanProfile] = None
                try:
                    fp = FanProfile(prof_val_i)
                except (TypeError, ValueError):
                    logger.warning("Hardware sync: ignoring invalid acpi_profile %r", prof_val)

                if fp is not None:
                    acpi_available = False
                    try:
                        ctrl = AcpiController()
                        acpi_available = ctrl.available
                        if ctrl.available:
                            current_profile = ctrl.get_profile()
                            if current_profile == fp:
                                results["profile"] = True
                                logger.debug(f"Hardware sync: ACPI power profile already {fp.name} ({fp.value}), skipping write")
                            elif ctrl.set_profile(fp):
                                results["profile"] = True
                                logger.info(f"Hardware sync: ACPI power profile set to {fp.name} ({fp.value})")
                    except Exception as exc:
                        logger.warning(f"Hardware sync failed for ACPI power profile: {exc}")

                    # System power sync also synchronizes GPU power (Dynamic Boost /
                    # SmartShift); honour the user's sync_system_power preference when ACPI is available.
                    if acpi_available:
                        try:
                            if cfg.get("sync_system_power", DEFAULT_CONFIG["sync_system_power"]):
                                from .system_power import sync_system_power

                                sync_system_power(int(prof_val))
                        except Exception as exc:
                            logger.warning(f"Hardware sync failed for system power: {exc}")

    # ─────────────────────────────────────────────────────────────
    # 2. Battery Care & Charging Limit
    # ─────────────────────────────────────────────────────────────
    if (
        cfg.get("charge_limit_enabled", DEFAULT_CONFIG["charge_limit_enabled"])
        or cfg.get("charge_topup_active", False)
        or cfg.get("charge_calibration_auto", False)
    ):
        try:
            from .battery import evaluate_calibration_state, get_battery_manager

            battery_mgr = get_battery_manager()
            cal = evaluate_calibration_state(battery_mgr, cfg)
        except Exception as exc:
            logger.warning(f"Hardware sync failed for battery calibration state: {exc}")
            cal = {"active": False, "event": "idle"}

        if cfg.get("charge_topup_active") or cal.get("event") == "auto_started":
            try:
                if battery_mgr.is_charge_limit_supported():
                    if battery_mgr.set_charge_limit(100):
                        results["battery"] = True
                        logger.info("Hardware sync: Battery charge top-up active (100%)")
            except Exception as exc:
                logger.warning(f"Hardware sync failed for battery charge top-up: {exc}")
        elif cfg.get("charge_limit_enabled", DEFAULT_CONFIG["charge_limit_enabled"]):
            limit = cfg.get("charge_limit", DEFAULT_CONFIG["charge_limit"])
            try:
                if battery_mgr.is_charge_limit_supported():
                    if battery_mgr.set_charge_limit(int(limit)):
                        results["battery"] = True
                        logger.info(f"Hardware sync: Battery charge limit set to {limit}%")
            except Exception as exc:
                logger.warning(f"Hardware sync failed for battery charge limit: {exc}")


    # ─────────────────────────────────────────────────────────────
    # 3. Keyboard RGB Lighting
    # ─────────────────────────────────────────────────────────────
    if force_keyboard or cfg.get("startup_apply", DEFAULT_CONFIG["startup_apply"]):
        try:
            from .protocol import get_keyboard, set_off, set_rgb

            # On boot/resume, USB devices might need a brief moment to settle
            dev = get_keyboard()
            if dev is None:
                for _ in range(2):
                    time.sleep(0.3)
                    dev = get_keyboard()
                    if dev is not None:
                        break

            if dev is not None:
                if not is_rgb_enabled(cfg):
                    ok = set_off(dev)
                    results["keyboard"] = bool(ok)
                    if ok:
                        logger.info("Hardware sync: Keyboard lighting turned off")
                else:
                    pct = max(1, effective_brightness_pct(cfg))
                    hex_color = effective_rgb_hex(cfg)
                    ok = set_rgb(dev, hex_color, pct)
                    results["keyboard"] = bool(ok)
                    if ok:
                        logger.info(
                            f"Hardware sync: Keyboard lighting set to {hex_color} (brightness {pct}%)"
                        )
        except Exception as exc:
            logger.warning(f"Hardware sync failed for keyboard lighting: {exc}")

    # ─────────────────────────────────────────────────────────────
    # 3b. Discrete GPU Power Gate (ECO / Auto)
    # ─────────────────────────────────────────────────────────────
    try:
        from . import dgpu_gate

        dgpu_gate.sync_policy(reason="hardware_sync")
    except Exception as exc:
        logger.warning(f"Hardware sync failed for dGPU power gate: {exc}")

    # ─────────────────────────────────────────────────────────────
    # 4. Discrete GPU tuning (sleep-aware; applies only if awake)
    # ─────────────────────────────────────────────────────────────
    try:
        from . import dgpu_gate, dgpu_tune

        if not dgpu_gate.should_pause_tuning():
            dgpu_tune.apply_from_config()
        results["dgpu"] = bool(
            (cfg.get("dgpu_undervolt_enabled", DEFAULT_CONFIG["dgpu_undervolt_enabled"])
             or cfg.get("dgpu_max_clock_enabled", DEFAULT_CONFIG["dgpu_max_clock_enabled"]))
            and cfg.get("dgpu_undervolt_auto", DEFAULT_CONFIG["dgpu_undervolt_auto"])
        )
    except Exception as exc:
        logger.warning(f"Hardware sync failed for dGPU tuning: {exc}")

    return results
