"""GigaMate — Discrete GPU (dGPU) power state monitoring.

Reads the power state of the discrete NVIDIA GPU from the kernel's PCI
runtime power-management sysfs interface:

    /sys/bus/pci/devices/<bdf>/power/runtime_status   -> "active" / "suspended"
    /sys/bus/pci/devices/<bdf>/power_state            -> "D0" / "D3hot" / "D3cold"

These are plain kernel bookkeeping reads: they never touch the GPU
hardware, so checking the state does NOT wake the GPU (unlike
`nvidia-smi`, which must not be used here).

The NVIDIA device is discovered by scanning /sys/bus/pci/devices for a
device with vendor 0x10de and PCI class 0x03xxxx (display controller),
so no PCI address is hard-coded.
"""

import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


PCI_SYSFS = Path("/sys/bus/pci/devices")

# NVIDIA vendor id as printed in /sys/bus/pci/devices/*/vendor
NVIDIA_VENDOR = "0x10de"

# AMD vendor id. Only *discrete* AMD GPUs count: the integrated GPU shares
# this vendor id but is always awake, so it must be excluded — see
# ``NvidiaGpuMonitor._is_integrated_amd`` for how the two are told apart.
AMD_VENDOR = "0x1002"

# An AMD APU's "dedicated" VRAM is really a carve-out of system memory; 1 GiB is
# comfortably above any plausible carve-out and far below any discrete board.
_UMA_APERTURE_MAX_BYTES = 1 << 30


@dataclass
class GpuState:
    """Snapshot of the discrete GPU power state.

    All fields except ``present`` are Optional — partial sysfs support is
    handled gracefully.
    """

    present: bool = False
    status: Optional[str] = None  # "active", "suspended", or "gated_off"
    power_state: Optional[str] = None  # "D0", "D3hot", "D3cold", "OFF", ...
    vendor: Optional[str] = None  # "nvidia", "amd", or None when absent
    dynamic_boost_supported: bool = False
    dynamic_boost_active: bool = False
    smartshift_supported: bool = False
    smartshift_bias: Optional[int] = None
    gated_off: bool = False


class NvidiaGpuMonitor:
    """Monitor for the power state and dynamic power features of a discrete GPU.

    Reads are sysfs-only and never wake the GPU.
    """

    def __init__(
        self,
        pci_sysfs: Optional[Path] = None,
        proc_nvidia: Optional[Path] = None,
    ) -> None:
        """Initialise monitor.

        Args:
            pci_sysfs: Override the PCI sysfs root (mainly for tests).
                        If None, the module-level ``PCI_SYSFS`` is used.
            proc_nvidia: Override the NVIDIA proc path (mainly for tests).
                         If None, Path("/proc/driver/nvidia") is used.
        """
        self._pci_sysfs: Optional[Path] = pci_sysfs
        self._proc_nvidia: Optional[Path] = proc_nvidia
        self._device: Optional[Path] = None
        self._vendor: Optional[str] = None
        # Cache the (relatively expensive) nvidia-powerd active query so the
        # UI telemetry timer does not issue DBus/systemctl calls every tick.
        self._boost_active_cache: Optional[tuple] = None
        # Dynamic Boost support cannot change without a reboot/rebind.
        self._boost_supported_cache: Optional[bool] = None

    @property
    def _sysfs_root(self) -> Path:
        return self._pci_sysfs or PCI_SYSFS

    def detect(self) -> bool:
        """Find the discrete GPU device. Returns True if found."""
        self._device, self._vendor = self._find_device()
        return self._device is not None

    @property
    def is_available(self) -> bool:
        """Whether a discrete GPU is present on the PCI bus."""
        if self._device is not None and not (self._device / "vendor").exists():
            # Handle PCI hot-remove (dGPU gated off) cleanly.
            self._device = None
            self._vendor = None
        if self._device is None:
            self.detect()
        return self._device is not None

    def read_state(self) -> GpuState:
        """Read the current GPU power state (sysfs only, never wakes it)."""
        if self._device is None and self._pci_sysfs is None:
            try:
                from .dgpu_gate import _BDF_RE, read_gate_state

                gate_state = read_gate_state()
                if gate_state.get("gated"):
                    bdf = gate_state.get("bdf")
                    if (
                        isinstance(bdf, str)
                        and _BDF_RE.fullmatch(bdf)
                        and not (self._sysfs_root / bdf).is_dir()
                    ):
                        return GpuState(
                            present=True,
                            status="gated_off",
                            power_state="OFF",
                            vendor=gate_state.get("vendor") or "nvidia",
                            gated_off=True,
                        )
            except Exception:
                pass
        if not self.is_available:
            if self._pci_sysfs is None:
                try:
                    from .dgpu_gate import read_gate_state

                    gate_state = read_gate_state()
                    if gate_state.get("gated"):
                        return GpuState(
                            present=True,
                            status="gated_off",
                            power_state="OFF",
                            vendor=gate_state.get("vendor") or "nvidia",
                            gated_off=True,
                        )
                except Exception:
                    pass
            return GpuState(present=False)

        state = GpuState(present=True, vendor=self._vendor)
        assert self._device is not None  # guaranteed by is_available
        state.status = self._read_text(self._device / "power" / "runtime_status")
        state.power_state = self._read_text(self._device / "power_state")

        if self._vendor == "nvidia":
            state.dynamic_boost_supported = self._check_dynamic_boost_supported()
            if state.dynamic_boost_supported:
                state.dynamic_boost_active = self._check_dynamic_boost_active()
        elif self._vendor == "amd":
            state.smartshift_supported = self._check_smartshift_supported()
            if state.smartshift_supported:
                state.smartshift_bias = self._read_smartshift_bias()

        return state

    def _find_device(self) -> tuple:
        """Scan the PCI sysfs root for a discrete GPU.

        Returns (device_path_or_None, vendor_or_None). NVIDIA matches take
        priority. AMD matches must not be integrated graphics — that is decided
        by amdgpu's own sysfs markers first (see ``_is_integrated_amd``) and only
        then by ``boot_vga``, which on its own is not enough: an APU iGPU also
        reports ``boot_vga=0`` whenever the dGPU is the primary display, and
        claiming it would light a permanent "discrete GPU" indicator on a
        machine that has none.
        """
        nvidia: Optional[Path] = None
        amd: Optional[Path] = None
        try:
            root = self._sysfs_root
            if not root.is_dir():
                return None, None
            for entry in root.iterdir():
                if not entry.is_dir():
                    continue
                try:
                    vendor = (entry / "vendor").read_text().strip()
                    cls = (entry / "class").read_text().strip()
                except OSError:
                    continue
                if not cls.startswith("0x03"):
                    continue
                if vendor == NVIDIA_VENDOR and nvidia is None:
                    nvidia = entry
                elif vendor == AMD_VENDOR and amd is None:
                    if self._is_integrated_amd(entry):
                        continue
                    # Accept AMD devices explicitly flagged as non-boot (boot_vga=0)
                    # or 3D controllers (PCI class 0x0302xx) which do not have a boot_vga attribute.
                    boot_vga = self._read_text(entry / "boot_vga")
                    if boot_vga == "0" or (cls.startswith("0x0302") and boot_vga != "1"):
                        amd = entry
        except OSError:
            pass
        if nvidia is not None:
            return nvidia, "nvidia"
        if amd is not None:
            return amd, "amd"
        return None, None

    def _is_integrated_amd(self, device: Path) -> bool:
        """Whether an AMD display device is an APU/iGPU rather than a dGPU.

        ``boot_vga`` cannot answer this: a hybrid laptop whose dGPU is the
        primary display reports ``boot_vga=0`` for *both* GPUs. amdgpu exposes
        two unambiguous markers instead, so use them first:

        * ``uma/`` only exists on APUs (it holds the carve-out controls).
        * ``mem_info_vram_total`` is the APU's shared-memory aperture, which is
          carve-out sized (512 MiB on a Krackan 840M) rather than the GBs of
          dedicated memory a Radeon board has.

        A discrete Radeon has neither, so it is unaffected.
        """
        if (device / "uma").is_dir():
            return True
        total = self._read_text(device / "mem_info_vram_total")
        if total:
            try:
                if int(total) < _UMA_APERTURE_MAX_BYTES:
                    return True
            except (TypeError, ValueError):
                pass
        return False

    def _read_text(self, path: Path) -> Optional[str]:
        """Read a sysfs text file, returning None on any failure."""
        try:
            text = path.read_text().strip()
            return text or None
        except (OSError, IOError):
            return None

    def _check_dynamic_boost_supported(self) -> bool:
        """Whether the dGPU supports Dynamic Boost (cached)."""
        if self._vendor != "nvidia":
            return False
        if self._boost_supported_cache is None:
            self._boost_supported_cache = self._query_dynamic_boost_supported()
        return self._boost_supported_cache

    def _query_dynamic_boost_supported(self) -> bool:
        """Check if discrete NVIDIA GPU supports Dynamic Boost."""
        # 1. Check /proc/driver/nvidia/gpus/*/power
        proc_root = self._proc_nvidia or Path("/proc/driver/nvidia")
        gpus_dir = proc_root / "gpus" if proc_root.name != "gpus" else proc_root
        found_power_file = False
        if gpus_dir.is_dir():
            try:
                for p in gpus_dir.iterdir():
                    power_file = p / "power"
                    if power_file.is_file():
                        found_power_file = True
                        content = power_file.read_text(errors="ignore")
                        if "Notebook Dynamic Boost:     Supported" in content or "Notebook Dynamic Boost: Supported" in content:
                            return True
            except (OSError, IOError):
                pass
        # If procfs power files existed and none indicated Supported, treat as unsupported
        if found_power_file:
            return False

        # 2. Check if nvidia-powerd service unit or binary exists
        for unit_dir in [Path("/usr/lib/systemd/system"), Path("/etc/systemd/system")]:
            if (unit_dir / "nvidia-powerd.service").is_file():
                return True
        if Path("/usr/bin/nvidia-powerd").is_file():
            return True

        return False

    _BOOST_ACTIVE_TTL = 10.0

    def _check_dynamic_boost_active(self) -> bool:
        """Cached view of whether nvidia-powerd.service is active."""
        now = time.monotonic()
        cache = self._boost_active_cache
        if cache is not None and (now - cache[0]) < self._BOOST_ACTIVE_TTL:
            return cache[1]
        result = self._query_dynamic_boost_active()
        self._boost_active_cache = (now, result)
        return result

    def _query_dynamic_boost_active(self) -> bool:
        """Check if nvidia-powerd.service is active (DBus/systemctl)."""
        if self._vendor != "nvidia":
            return False

        # 1. Try DBus query
        try:
            import gi
            gi.require_version("Gio", "2.0")
            from gi.repository import Gio
            bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
            proxy = Gio.DBusProxy.new_sync(
                bus,
                Gio.DBusProxyFlags.NONE,
                None,
                "org.freedesktop.systemd1",
                "/org/freedesktop/systemd1/unit/nvidia_2dpowerd_2eservice",
                "org.freedesktop.DBus.Properties",
                None,
            )
            val = proxy.call_sync(
                "Get",
                gi.repository.GLib.Variant("(ss)", ("org.freedesktop.systemd1.Unit", "ActiveState")),
                Gio.DBusCallFlags.NONE,
                300,
                None,
            )
            if val and len(val) > 0:
                res = val[0]
                if isinstance(res, str):
                    return res == "active"
                if hasattr(res, "get_string"):
                    return res.get_string() == "active"
                return str(res) == "active"
        except Exception:
            pass

        # 2. Fallback to systemctl is-active
        try:
            import subprocess
            res = subprocess.run(
                ["systemctl", "is-active", "--quiet", "nvidia-powerd.service"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=1,
            )
            return res.returncode == 0
        except Exception:
            return False

    def _start_nvidia_powerd(self) -> bool:
        """Attempt to start nvidia-powerd.service silently."""
        self._boost_active_cache = None  # invalidate cached active state
        # 1. Try DBus systemd Manager StartUnit
        try:
            import gi
            gi.require_version("Gio", "2.0")
            gi.require_version("GLib", "2.0")
            from gi.repository import Gio, GLib
            bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
            proxy = Gio.DBusProxy.new_sync(
                bus,
                Gio.DBusProxyFlags.NONE,
                None,
                "org.freedesktop.systemd1",
                "/org/freedesktop/systemd1",
                "org.freedesktop.systemd1.Manager",
                None,
            )
            try:
                proxy.call_sync(
                    "ResetFailedUnit",
                    GLib.Variant("(s)", ("nvidia-powerd.service",)),
                    Gio.DBusCallFlags.NONE,
                    500,
                    None,
                )
            except Exception:
                pass
            proxy.call_sync(
                "StartUnit",
                GLib.Variant("(ss)", ("nvidia-powerd.service", "replace")),
                Gio.DBusCallFlags.NONE,
                1000,
                None,
            )
            return True
        except Exception:
            pass

        # 2. Fallback to systemctl start
        try:
            import subprocess
            subprocess.run(
                ["systemctl", "reset-failed", "nvidia-powerd.service"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=2,
            )
            res = subprocess.run(
                ["systemctl", "start", "nvidia-powerd.service"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=2,
            )
            return res.returncode == 0
        except Exception:
            return False

    def _check_smartshift_supported(self) -> bool:
        """Check if discrete AMD GPU supports SmartShift."""
        if self._vendor != "amd" or not self._device:
            return False
        return (
            (self._device / "smartshift_bias").exists()
            or (self._device / "smartshift_apu_power").exists()
            or (self._device / "smartshift_dgpu_power").exists()
        )

    def _read_smartshift_bias(self) -> Optional[int]:
        """Read smartshift_bias from AMD dGPU sysfs."""
        if self._vendor != "amd" or not self._device:
            return None
        path = self._device / "smartshift_bias"
        try:
            text = path.read_text().strip()
            return int(text)
        except (OSError, ValueError, IOError):
            return None

    def sync_power(self, fan_profile_id: int) -> bool:
        """Apply GPU power tuning matching the selected fan profile."""
        if self._pci_sysfs is None:
            try:
                from .dgpu_gate import is_gated_off

                if is_gated_off():
                    return True
            except Exception:
                pass
        if not self.is_available:
            return True

        # 1. NVIDIA Dynamic Boost automation
        if self._vendor == "nvidia":
            # For Gaming (3) or Performance (2), ensure nvidia-powerd is running
            if fan_profile_id in (2, 3):
                try:
                    from . import dgpu_gate

                    if dgpu_gate.is_gated_off() or dgpu_gate.should_pause_tuning():
                        return True
                except Exception:
                    pass
                if self._check_dynamic_boost_supported() and not self._check_dynamic_boost_active():
                    return self._start_nvidia_powerd()
            return True

        # 2. AMD SmartShift automation
        if self._vendor == "amd":
            if not self._device:
                return True
            bias_path = self._device / "smartshift_bias"
            if bias_path.exists() and os.access(str(bias_path), os.W_OK):
                # 3 (Gaming) -> 100, 2 (Performance) -> 50, 1 (Balanced) -> 0, 0 (Quiet) -> -50
                bias_val = {3: 100, 2: 50, 1: 0, 0: -50}.get(fan_profile_id, 0)
                try:
                    bias_path.write_text(f"{bias_val}\n")
                    return True
                except (OSError, IOError):
                    return False
            return True

        return True


# Global helper instance
_monitor = NvidiaGpuMonitor()


def gpu_status_text(state: GpuState) -> str:
    """Human-readable GPU power status suitable for UI display."""
    if not state.present:
        return "Not present"
    if state.gated_off or state.status == "gated_off":
        return "Off (gated)"
    status = state.status
    power = state.power_state
    if status == "suspended":
        return f"Asleep ({power})" if power else "Asleep"
    if status == "active":
        return f"Awake ({power})" if power else "Awake"
    if status in ("suspending", "resuming"):
        return f"{status.capitalize()} ({power})" if power else status.capitalize()
    if power:
        return f"Unknown ({power})"
    return "Unknown"


def gpu_short_status_text(state: GpuState) -> str:
    """Return a short status label: 'Off (gated)', 'Asleep', 'Awake', 'Unknown', or 'Not present'."""
    if not state.present:
        return "Not present"
    if state.gated_off or state.status == "gated_off":
        return "Off (gated)"
    status = state.status or ""
    if status == "suspended":
        return "Asleep"
    if status == "active":
        return "Awake"
    if status in ("suspending", "resuming"):
        return status.capitalize()
    return "Unknown"


# Tray icon keys per (vendor, awake). Distinct files (not runtime rewrites)
# so indicator hosts refresh reliably. Unknown vendors fall back to plain.
GPU_ICON_KEYS = {
    ("nvidia", True): "gigamate-nvidia",
    ("amd", True): "gigamate-amd",
}


def gpu_icon_key(state: GpuState) -> str:
    """Map a GpuState to a tray icon key (plain when not awake/absent/gated)."""
    try:
        if not state.present or state.gated_off or state.status != "active" or not state.vendor:
            return "gigamate"
        return GPU_ICON_KEYS.get((state.vendor, True), "gigamate")
    except Exception:
        return "gigamate"


def get_gpu_state() -> GpuState:
    """Read the current discrete GPU power state (sysfs only, never wakes it)."""
    return _monitor.read_state()


def sync_gpu_power(fan_profile_id: int) -> bool:
    """Synchronize GPU power features (Dynamic Boost / SmartShift) with the profile.

    Args:
        fan_profile_id: 0 (Quiet), 1 (Balanced), 2 (Performance), 3 (Gaming)

    Returns:
        True on success or if no action required; False on failure.
        Never raises exceptions (graceful degradation).
    """
    try:
        return _monitor.sync_power(fan_profile_id)
    except Exception:
        return False
