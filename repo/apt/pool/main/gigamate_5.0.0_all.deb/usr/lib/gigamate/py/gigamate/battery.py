"""GigaMate — Battery Care & Charging Threshold Management.

Provides hardware detection and control for laptop battery charge thresholds
(e.g. capping maximum charge at 80% to preserve battery lifespan), battery
health diagnostics, and AC connection status monitoring.

Supports:
1. GigaMate ACPI sysfs interface:
   /sys/devices/platform/gigamate_acpi/charge_limit
2. Standard Linux power supply charge control:
   /sys/class/power_supply/BAT*/charge_control_end_threshold
3. AC/Mains online status:
   /sys/class/power_supply/AC*/online
"""

from dataclasses import dataclass
import logging
import os
import time
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

POWER_SUPPLY_SYSFS = Path("/sys/class/power_supply")
GIGAMATE_ACPI_SYSFS = Path("/sys/devices/platform/gigamate_acpi")


@dataclass
class BatteryInfo:
    """Snapshot of laptop battery status, health, and charge limits."""

    present: bool = False
    name: str = "BAT0"
    status: str = "Unknown"  # "Charging", "Discharging", "Full", "Not charging"
    capacity: int = 0  # 0..100 %
    health_percent: Optional[float] = None  # charge_full / charge_full_design * 100
    cycle_count: Optional[int] = None
    charge_now: Optional[int] = None  # µAh or µWh
    charge_full: Optional[int] = None
    charge_full_design: Optional[int] = None
    ac_online: bool = False
    charge_limit: Optional[int] = None  # Active charge limit (e.g. 80)
    charge_limit_supported: bool = False
    backend: str = "none"  # "gigamate_acpi", "sysfs", "none"


class BatteryManager:
    """Detects and controls battery charging thresholds and monitoring."""

    def __init__(
        self,
        power_supply_dir: Optional[Path] = None,
        acpi_sysfs_dir: Optional[Path] = None,
    ) -> None:
        self._power_supply_dir = power_supply_dir or POWER_SUPPLY_SYSFS
        self._acpi_sysfs_dir = acpi_sysfs_dir or GIGAMATE_ACPI_SYSFS
        self._battery_path: Optional[Path] = None
        self._ac_path: Optional[Path] = None
        self._detect_paths()

    def _detect_paths(self) -> None:
        """Discover active battery and AC adapter directories in sysfs."""
        self._battery_paths: list = []
        if not self._power_supply_dir.exists():
            return

        def _type_of(path: Path) -> Optional[str]:
            type_file = path / "type"
            if type_file.exists():
                try:
                    return type_file.read_text().strip().lower()
                except (OSError, PermissionError):
                    return None
            return None

        try:
            entries = sorted(self._power_supply_dir.iterdir())
        except (OSError, PermissionError):
            return

        batteries = []
        for path in entries:
            if path.is_dir() and _type_of(path) == "battery":
                batteries.append(path)

        self._battery_paths = batteries

        # Prefer the first battery that explicitly reports itself present,
        # so a pack on BAT1 is still found when BAT0 reports present=0.
        for path in batteries:
            present_file = path / "present"
            if present_file.exists():
                try:
                    if present_file.read_text().strip() == "0":
                        continue
                except (OSError, PermissionError):
                    pass
            self._battery_path = path
            break
        else:
            if batteries:
                self._battery_path = batteries[0]

        # Find AC / Mains adapter (AC, ACAD, ADP1, USB-C PD, etc.)
        for path in entries:
            if path.is_dir() and _type_of(path) in ("mains", "ac", "usb", "usb_pd"):
                self._ac_path = path
                break

    @property
    def battery_path(self) -> Optional[Path]:
        return self._battery_path

    @property
    def is_available(self) -> bool:
        """Whether a battery is detected on this system."""
        if self._battery_path is None:
            return False

        present_file = self._battery_path / "present"
        if present_file.exists():
            try:
                return present_file.read_text().strip() != "0"
            except (OSError, PermissionError):
                pass

        # Some batteries omit the `present` attribute; the discovered device
        # directory itself is sufficient evidence that a battery exists.
        return True

    def is_ac_online(self) -> bool:
        """Returns True if AC adapter is connected and delivering power."""
        if self._ac_path:
            online_file = self._ac_path / "online"
            if online_file.exists():
                try:
                    return online_file.read_text().strip() == "1"
                except (OSError, PermissionError):
                    pass

        # Fallback: check mains-like supplies for online == 1 (ignore unrelated
        # online supplies such as USB gadgets or peripherals).
        if self._power_supply_dir.exists():
            for p in self._power_supply_dir.glob("*/online"):
                supply = p.parent
                type_file = supply / "type"
                try:
                    stype = type_file.read_text().strip().lower() if type_file.exists() else ""
                except (OSError, PermissionError):
                    continue
                if stype not in ("mains", "ac", "usb", "usb_pd"):
                    continue
                try:
                    if p.read_text().strip() == "1":
                        return True
                except (OSError, PermissionError):
                    continue
        return False

    def is_charge_limit_supported(self) -> bool:
        """Whether this process can actually set a battery charge limit.

        The kernel module always creates the ``charge_limit`` attribute, so we
        must read it (``-ENODATA`` means the EC is unsupported). For the
        standard kernel attribute we also require write access — on most
        non-Gigabyte laptops it is root-only, so we report unsupported rather
        than offering a control that will fail on apply.
        """
        # 1. GigaMate ACPI sysfs module attribute
        acpi_file = self._acpi_sysfs_dir / "charge_limit"
        if acpi_file.exists():
            try:
                val = int(acpi_file.read_text().strip())
                if 0 < val <= 100 and os.access(str(acpi_file), os.W_OK):
                    return True
            except (OSError, ValueError):
                pass  # fall through to the standard attribute

        # 2. Linux standard kernel charge_control_end_threshold
        if self._battery_path:
            std_file = self._battery_path / "charge_control_end_threshold"
            if std_file.exists() and os.access(str(std_file), os.W_OK):
                try:
                    int(std_file.read_text().strip())
                    return True
                except (OSError, ValueError):
                    return False

        return False

    def get_charge_limit(self) -> Optional[int]:
        """Read the currently configured charge limit (e.g. 80), or None if unsupported."""
        # 1. Check GigaMate ACPI module
        acpi_file = self._acpi_sysfs_dir / "charge_limit"
        if acpi_file.exists():
            try:
                val = int(acpi_file.read_text().strip())
                if 0 < val <= 100:
                    return val
            except (ValueError, OSError):
                pass

        # 2. Check standard kernel attribute
        if self._battery_path:
            std_file = self._battery_path / "charge_control_end_threshold"
            if std_file.exists():
                try:
                    val = int(std_file.read_text().strip())
                    if 0 < val <= 100:
                        return val
                except (ValueError, OSError):
                    pass

        return None

    def set_charge_limit(self, limit: int) -> bool:
        """Set maximum battery charge limit percentage (40..100, where 100 or 0 is standard/unlimited).

        Returns True on success, False otherwise.
        """
        if limit is None:
            raise ValueError("Charge limit cannot be None")
        try:
            val = int(limit)
        except (TypeError, ValueError):
            raise ValueError(f"Invalid charge limit value: {limit!r}")

        if not (40 <= val <= 100):
            raise ValueError(f"Charge limit must be between 40 and 100 percent (got {limit})")
        limit = val

        # 1. Try GigaMate ACPI module
        acpi_file = self._acpi_sysfs_dir / "charge_limit"
        if acpi_file.exists():
            try:
                acpi_file.write_text(f"{limit}\n")
                return True
            except (OSError, PermissionError) as exc:
                logger.warning(f"Failed to write to {acpi_file}: {exc}")

        # 2. Try standard sysfs attribute on all detected batteries
        success = False
        target_paths = self._battery_paths if self._battery_paths else ([self._battery_path] if self._battery_path else [])
        for bpath in target_paths:
            std_file = bpath / "charge_control_end_threshold"
            if std_file.exists():
                try:
                    std_file.write_text(f"{limit}\n")
                    success = True
                except (OSError, PermissionError) as exc:
                    logger.warning(f"Failed to write to {std_file}: {exc}")

        return success

    def get_battery_info(self) -> BatteryInfo:
        """Return comprehensive snapshot of battery status and health."""
        if not self.is_available or not self._battery_path:
            return BatteryInfo(
                present=False,
                ac_online=self.is_ac_online(),
                charge_limit_supported=self.is_charge_limit_supported(),
            )

        info = BatteryInfo(
            present=True,
            name=self._battery_path.name,
            ac_online=self.is_ac_online(),
            charge_limit=self.get_charge_limit(),
            charge_limit_supported=self.is_charge_limit_supported(),
        )

        if self.is_charge_limit_supported():
            acpi_file = self._acpi_sysfs_dir / "charge_limit"
            if acpi_file.exists() and os.access(str(acpi_file), os.W_OK):
                try:
                    val = int(acpi_file.read_text().strip())
                    if 0 < val <= 100:
                        info.backend = "gigamate_acpi"
                except (OSError, ValueError):
                    pass
            if info.backend == "none" and self._battery_path:
                info.backend = "sysfs"

        def _read_int(filename: str) -> Optional[int]:
            p = self._battery_path / filename
            if p.exists():
                try:
                    return int(p.read_text().strip())
                except (ValueError, OSError):
                    pass
            return None

        def _read_str(filename: str) -> Optional[str]:
            p = self._battery_path / filename
            if p.exists():
                try:
                    return p.read_text().strip()
                except OSError:
                    pass
            return None

        info.capacity = _read_int("capacity") or 0
        info.status = _read_str("status") or "Unknown"
        info.cycle_count = _read_int("cycle_count")

        # Health calculation: strictly match units (µAh vs µAh, or µWh vs µWh)
        c_now = _read_int("charge_now")
        c_full = _read_int("charge_full")
        c_design = _read_int("charge_full_design")
        e_now = _read_int("energy_now")
        e_full = _read_int("energy_full")
        e_design = _read_int("energy_full_design")

        health = None
        if c_full and c_design and c_design > 0:
            health = (c_full / c_design) * 100.0
            info.charge_now = c_now
            info.charge_full = c_full
            info.charge_full_design = c_design
        elif e_full and e_design and e_design > 0:
            health = (e_full / e_design) * 100.0
            info.charge_now = e_now
            info.charge_full = e_full
            info.charge_full_design = e_design
        else:
            info.charge_now = c_now or e_now
            info.charge_full = c_full or e_full
            info.charge_full_design = c_design or e_design

        if health is not None:
            info.health_percent = round(min(100.0, max(0.0, health)), 1)

        return info


_default_manager: Optional[BatteryManager] = None


def get_battery_manager() -> BatteryManager:
    """Singleton getter for default BatteryManager."""
    global _default_manager
    if _default_manager is None:
        _default_manager = BatteryManager()
    return _default_manager


def is_effectively_full(info: BatteryInfo) -> bool:
    """Returns True if battery is effectively full.

    Present and (status == 'Full' or (capacity >= 99 and status in ('Full', 'Not charging', 'Unknown'))).
    """
    if not getattr(info, "present", False):
        return False
    status = getattr(info, "status", "")
    try:
        cap = int(getattr(info, "capacity", 0) or 0)
    except (ValueError, TypeError):
        cap = 0
    if cap >= 99 and status in ("Full", "Not charging", "Unknown"):
        return True
    return False


def start_topup(mgr: Optional[BatteryManager] = None) -> bool:
    """Start a top-up charge to 100%.

    Uses ``mgr`` or ``get_battery_manager()``. Returns False if charge limit
    is not supported. Writes 100 via ``set_charge_limit(100)`` and atomically
    updates config: ``charge_topup_active=True``, ``charge_topup_started_ts``.
    """
    from .config import update_config

    if mgr is None:
        mgr = get_battery_manager()

    if not mgr.is_charge_limit_supported():
        return False

    if not mgr.set_charge_limit(100):
        return False

    update_config(lambda c: {**c, "charge_topup_active": True, "charge_topup_started_ts": int(time.time())})
    return True


def cancel_topup(mgr: Optional[BatteryManager] = None, restore_limit: bool = True) -> bool:
    """Cancel an in-progress top-up.

    Uses ``mgr`` or ``get_battery_manager()``. Atomically updates config:
    ``charge_topup_active=False``, ``charge_topup_started_ts=0``.

    If ``restore_limit`` is True, restores the charge limit from config
    (if ``charge_limit_enabled`` is set, targets the stored limit clamped to
    [40, 100]).
    """
    from .config import update_config, load as load_config

    if mgr is None:
        mgr = get_battery_manager()

    update_config(lambda c: {**c, "charge_topup_active": False, "charge_topup_started_ts": 0})

    if restore_limit:
        cfg = load_config()
        if cfg.get("charge_limit_enabled"):
            target = cfg.get("charge_limit", 80)
            if 40 <= target <= 100:
                mgr.set_charge_limit(target)
    return True


def evaluate_calibration_state(mgr: Optional[BatteryManager] = None, cfg: Optional[dict] = None) -> dict:
    """Evaluate the battery calibration state machine.

    Uses ``mgr`` or ``get_battery_manager()``. If ``cfg`` is None, loads from
    disk via ``load_config()``.

    Returns a dict with keys ``active`` (bool) and ``event`` (str or None).
    Possible events: 'completed', 'timeout', 'auto_started', 'in_progress', 'idle'.
    """
    from .config import update_config, load as load_config

    if mgr is None:
        mgr = get_battery_manager()

    if cfg is None:
        cfg = load_config()

    if not getattr(mgr, "is_available", False):
        return {"active": False, "reason": "no_battery"}

    info = mgr.get_battery_info()
    now = int(time.time())

    # Record last_full_charge_ts on edge or throttled (once per hour when full)
    if is_effectively_full(info):
        try:
            last_full = int(cfg.get("last_full_charge_ts", 0) or 0)
        except (ValueError, TypeError):
            last_full = 0
        if abs(now - last_full) > 3600:
            update_config(lambda c: {**c, "last_full_charge_ts": now})

    # If topup in progress:
    if cfg.get("charge_topup_active"):
        if is_effectively_full(info):
            cancel_topup(mgr=mgr, restore_limit=True)
            update_config(lambda c: {**c, "last_full_charge_ts": now})
            return {"active": False, "event": "completed"}
        try:
            started = int(cfg.get("charge_topup_started_ts", 0) or 0)
        except (ValueError, TypeError):
            started = 0
        if started > 0 and (now - started >= 86400 or now < started):
            cancel_topup(mgr=mgr, restore_limit=True)
            return {"active": False, "event": "timeout"}
        return {"active": True, "event": "in_progress"}

    # Check periodic auto-calibration:
    if cfg.get("charge_limit_enabled") and cfg.get("charge_limit", 80) < 100 and cfg.get("charge_calibration_auto"):
        if not cfg.get("charge_topup_active") and getattr(info, "ac_online", False):
            try:
                last_full = int(cfg.get("last_full_charge_ts", 0) or 0)
            except (ValueError, TypeError):
                last_full = 0
            try:
                interval_days = int(cfg.get("charge_calibration_interval_days", 30) or 30)
            except (ValueError, TypeError):
                interval_days = 30
            if last_full <= 0:
                try:
                    baseline = int(cfg.get("charge_calibration_baseline_ts", 0) or 0)
                except (ValueError, TypeError):
                    baseline = 0
                if baseline <= 0:
                    update_config(lambda c: {**c, "charge_calibration_baseline_ts": now})
                elif (now - baseline) >= interval_days * 86400:
                    if start_topup(mgr=mgr):
                        return {"active": True, "event": "auto_started"}
            elif (now - last_full) >= interval_days * 86400:
                if start_topup(mgr=mgr):
                    return {"active": True, "event": "auto_started"}
    return {"active": False, "event": "idle"}

