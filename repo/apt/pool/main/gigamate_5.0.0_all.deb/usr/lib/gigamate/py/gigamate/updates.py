"""GigaMate — Battery-efficient update checking.

Only trusts tags/releases created by the maintainer (manual batched
releases like ``v2.0.1``). Contributors via forks/PRs cannot push tags
to the upstream repo, so any ``vX.Y.Z`` tag on upstream is authoritative.

Design for battery efficiency:
- At most one tiny HTTPS request per 24h (cached timestamp in
  ``update_state.json``).
- Network I/O runs in a background thread from the tray; never on the
  GTK main loop.
- Failures are silent and cached — no retry storms.

Stdlib only (urllib + json), gi-free so tests run without PyGObject.
"""

import fcntl
import json
import os
import re
import shlex
import shutil
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable, Dict, Mapping, Optional, Tuple

from .paths import CONFIG_DIR

REPO = "goodeesh/GigaMate"
RELEASE_LATEST_URL = f"https://api.github.com/repos/{REPO}/releases/latest"
# Fallback when no GitHub Release exists yet (only tags pushed).
TAGS_URL = f"https://api.github.com/repos/{REPO}/tags?per_page=1"
RAW_VERSION_URL = (
    f"https://raw.githubusercontent.com/{REPO}/main/src/gigamate/__init__.py"
)
# Last-resort bootstrap ref used only when no valid release tag is known.
INSTALL_URL = f"https://raw.githubusercontent.com/{REPO}/main/install.sh"

CHECK_INTERVAL_SEC = 24 * 3600  # daily + startup
CHECK_JITTER_SEC = 30 * 60  # tray adds 0-30m jitter to the 24h timer
FETCH_TIMEOUT_SEC = 5

STATE_FILE = CONFIG_DIR / "update_state.json"

_TAG_RE = re.compile(r"^v?(\d+)\.(\d+)\.(\d+)$")
# Tag validation requires a leading 'v' (maintainer-pushed release tags).
_VALID_TAG_RE = re.compile(r"^v(\d+)\.(\d+)\.(\d+)(?:[-.]?(a|b|rc|alpha|beta)[-.]?(\d+)?)?$")
# Version parsing for comparison allows an optional 'v'.
_PRERELEASE_VERSION_RE = re.compile(r"^v?(\d+)\.(\d+)\.(\d+)(?:[-.]?(a|b|rc|alpha|beta)[-.]?(\d+)?)?$")
_PRE_RANK = {"a": 0, "alpha": 0, "b": 1, "beta": 1, "rc": 2, "": 3}


def parse_version(text: str) -> Tuple[int, int, int]:
    """Parse '2.0.1' or 'v2.0.1' into a comparable tuple. Raises ValueError."""
    m = _TAG_RE.match(text.strip())
    if not m:
        raise ValueError(f"Invalid version: {text!r}")
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)))


def _version_key(text: str) -> Tuple[int, int, int, int, int]:
    """Comparable key including pre-release ordering (a < b < rc < final)."""
    m = _PRERELEASE_VERSION_RE.match((text or "").strip())
    if not m:
        raise ValueError(f"Invalid version: {text!r}")
    pre = m.group(4) or ""
    pre_num = int(m.group(5)) if m.group(5) else 0
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)),
            _PRE_RANK[pre], pre_num)


def is_newer(latest: str, current: str) -> bool:
    """True if latest > current (handles pre-release suffixes)."""
    try:
        return _version_key(latest) > _version_key(current)
    except ValueError:
        return False


def is_valid_tag(tag: str) -> bool:
    """Only maintainer-pushed release tags count (vX.Y.Z[, aN|bN|rcN])."""
    return bool(_VALID_TAG_RE.match((tag or "").strip()))


def get_installed_version() -> str:
    from . import __version__
    return __version__


def should_check(now_ts: float, last_check_ts: Optional[float],
                 interval_sec: int = CHECK_INTERVAL_SEC) -> bool:
    if last_check_ts is None:
        return True
    try:
        return (float(now_ts) - float(last_check_ts)) >= interval_sec
    except (TypeError, ValueError):
        return True


def load_state(state_file: Path = STATE_FILE) -> Dict:
    try:
        if state_file.exists():
            data = json.loads(state_file.read_text())
            if isinstance(data, dict):
                return data
    except (OSError, json.JSONDecodeError):
        pass
    return {}


def save_state(state: Dict, state_file: Path = STATE_FILE) -> None:
    """Atomically persist update state, serialized across processes."""
    try:
        state_file.parent.mkdir(parents=True, exist_ok=True)
        lock_path = state_file.with_name(state_file.name + ".lock")
        lock = open(lock_path, "a+")
        try:
            fcntl.flock(lock, fcntl.LOCK_EX)
            _save_state_locked(state, state_file)
        finally:
            try:
                fcntl.flock(lock, fcntl.LOCK_UN)
            except OSError:
                pass
            lock.close()
    except OSError:
        pass


def _save_state_locked(state: Dict, state_file: Path) -> None:
    """Write state assuming the file lock is already held."""
    tmp = state_file.with_name(state_file.name + f".tmp.{os.getpid()}")
    try:
        tmp.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, state_file)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def update_update_state(mutator, state_file: Path = STATE_FILE) -> Dict:
    """Atomically read-modify-write the update state under the file lock."""
    state_file.parent.mkdir(parents=True, exist_ok=True)
    lock_path = state_file.with_name(state_file.name + ".lock")
    lock = open(lock_path, "a+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state = load_state(state_file)
        result = mutator(state)
        if isinstance(result, dict):
            state = result
        _save_state_locked(state, state_file)
        return state
    finally:
        try:
            fcntl.flock(lock, fcntl.LOCK_UN)
        except OSError:
            pass
        lock.close()


def _http_get_json(url: str, timeout: int,
                   urlopen: Callable = urllib.request.urlopen
                   ) -> Tuple[Optional[Dict], bool]:
    """GET a JSON object. Returns (data|None, reachable).

    ``reachable`` is False only on connection-level failure. An HTTP
    error (e.g. 404 no releases yet) still means GitHub is reachable.
    """
    try:
        req = urllib.request.Request(
            url, headers={"Accept": "application/vnd.github+json",
                          "User-Agent": "GigaMate-update-check"})
        with urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", "replace")), True
    except urllib.error.HTTPError:
        return None, True
    except Exception:
        return None, False


def _http_get_json_list(url: str, timeout: int,
                        urlopen: Callable = urllib.request.urlopen
                        ) -> Tuple[Optional[list], bool]:
    try:
        req = urllib.request.Request(
            url, headers={"Accept": "application/vnd.github+json",
                          "User-Agent": "GigaMate-update-check"})
        with urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
            return (data if isinstance(data, list) else None), True
    except urllib.error.HTTPError:
        return None, True
    except Exception:
        return None, False


def _http_reachable(urlopen: Callable = urllib.request.urlopen) -> bool:
    """True if api.github.com answers at all (even 404 = reachable)."""
    _, reachable = _http_get_json(RELEASE_LATEST_URL, FETCH_TIMEOUT_SEC,
                                  urlopen)
    return reachable


def fetch_latest_version(timeout: int = FETCH_TIMEOUT_SEC,
                         urlopen: Callable = urllib.request.urlopen
                         ) -> Optional[str]:
    """Fetch latest release tag from GitHub. Returns 'vX.Y.Z' or None."""
    data, _ = _http_get_json(RELEASE_LATEST_URL, timeout, urlopen)
    if isinstance(data, dict):
        tag = (data.get("tag_name") or "").strip()
        if is_valid_tag(tag):
            return tag
    # Fallback: newest tag (covers repos with tags but no Release yet).
    tags, _ = _http_get_json_list(TAGS_URL, timeout, urlopen)
    if tags:
        tag = ((tags[0] or {}).get("name") or "").strip()
        if is_valid_tag(tag):
            return tag

    # Fallback: __init__.py on main via raw.githubusercontent.com (not API rate limited)
    try:
        req = urllib.request.Request(RAW_VERSION_URL, headers={"User-Agent": "GigaMate-update-check"})
        with urlopen(req, timeout=timeout) as resp:
            content = resp.read().decode("utf-8", "replace")
            m = re.search(r'(?:__version__|version)\s*=\s*["\']([^"\']+)["\']', content)
            if m:
                v = m.group(1).strip()
                tag = f"v{v}" if not v.startswith("v") else v
                if is_valid_tag(tag):
                    return tag
    except Exception:
        pass

    return None


def check_for_updates(force: bool = False,
                      timeout: int = FETCH_TIMEOUT_SEC,
                      now_ts: Optional[float] = None,
                      state_file: Path = STATE_FILE,
                      urlopen: Callable = urllib.request.urlopen) -> Dict:
    """Battery-efficient check.

    Returns {"current":, "latest":|None, "update_available": bool,
             "checked_now": bool, "reachable": bool}. Uses cached state
    unless forced or the 24h interval elapsed. Never raises on failure.
    ``reachable`` tells whether github.com answered (False = offline;
    True + latest None = no releases/tags published yet).
    """
    now = now_ts if now_ts is not None else time.time()
    current = get_installed_version()
    state = load_state(state_file)
    cached_latest = state.get("latest_known")

    if not force and not should_check(now, state.get("last_check_ts")):
        latest = cached_latest if isinstance(cached_latest, str) else None
        dismissed = state.get("dismissed_version")
        avail = bool(latest and is_newer(latest, current)
                     and dismissed != latest)
        return {"current": current, "latest": latest,
                "update_available": avail, "checked_now": False,
                "reachable": True}

    latest = fetch_latest_version(timeout=timeout, urlopen=urlopen)
    reachable = latest is not None or _http_reachable(urlopen)
    # Merge under the file lock so a concurrent tray/CLI dismiss is preserved.
    def _merge(state):
        state["last_check_ts"] = now
        if latest:
            state["latest_known"] = latest
        return state
    state = update_update_state(_merge, state_file)

    known = latest or (cached_latest if isinstance(cached_latest, str) else None)
    dismissed = state.get("dismissed_version")
    avail = bool(known and is_newer(known, current)
                 and dismissed != known)
    return {"current": current, "latest": known,
            "update_available": avail, "checked_now": latest is not None,
            "reachable": reachable}


def dismiss_version(tag: str, state_file: Path = STATE_FILE) -> None:
    def _dismiss(state):
        state["dismissed_version"] = tag
        return state
    update_update_state(_dismiss, state_file)


def undismiss(state_file: Path = STATE_FILE) -> None:
    """Clear a dismissal (e.g. after a failed update) so the badge returns."""
    def _undismiss(state):
        state.pop("dismissed_version", None)
        return state
    update_update_state(_undismiss, state_file)


def admin_status(run: Callable = subprocess.run) -> str:
    """Check administrator rights for the driver parts of an update.

    Returns one of:
      "ok"       passwordless sudo (or cached) — no prompt will appear
      "password" user has sudo but must enter a password (system will prompt)
      "denied"   user is not in sudoers — privileged steps will fail
      "no-sudo"  sudo binary not present at all

    gi-free; ``run`` injectable for tests.
    """
    try:
        proc = run(["sudo", "-n", "true"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                   timeout=10)
    except FileNotFoundError:
        return "no-sudo"
    except Exception:
        return "denied"
    if proc.returncode == 0:
        return "ok"
    err = ""
    try:
        err = (proc.stderr or b"").decode("utf-8", "replace").lower()
    except Exception:
        pass
    if "sudoers" in err or "not allowed" in err or "unknown user" in err:
        return "denied"
    return "password"


UPDATE_LOG_FILE = CONFIG_DIR / "update.log"
INSTALL_METHOD_FILE = Path("/usr/lib/gigamate/install-method")
_PACKAGE_INSTALL_METHODS = frozenset({"apt", "dnf", "zypper", "pacman", "aur"})


def detect_install_method(
        marker_path: Path = INSTALL_METHOD_FILE,
        which: Callable[[str], Optional[str]] = shutil.which,
        run: Callable = subprocess.run) -> str:
    """Detect how GigaMate was installed.

    Returns one of ``"apt"``, ``"dnf"``, ``"zypper"``, ``"pacman"``, ``"aur"``,
    or ``"script"``. Checks ``marker_path`` first, then falls back to probing
    the system package manager owning the ``gigamate`` binary. Never raises.
    """
    try:
        if marker_path.exists():
            val = marker_path.read_text(encoding="utf-8", errors="replace").strip().lower()
            if val in _PACKAGE_INSTALL_METHODS:
                return val
            if val == "script":
                return "script"
    except Exception:
        pass

    try:
        exe = which("gigamate")
    except Exception:
        exe = None
    if not exe:
        return "script"

    def _owns(cmd: list) -> bool:
        try:
            proc = run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
            return getattr(proc, "returncode", 1) == 0
        except Exception:
            return False

    try:
        if which("pacman") and _owns(["pacman", "-Qo", exe]):
            return "pacman"
        if which("dpkg") and _owns(["dpkg", "-S", exe]):
            return "apt"
        if which("rpm") and _owns(["rpm", "-qf", exe]):
            if which("zypper") and not which("dnf"):
                return "zypper"
            return "dnf"
    except Exception:
        pass

    return "script"


def is_package_managed(method: Optional[str] = None) -> bool:
    """True when GigaMate is managed by a native Linux package manager."""
    if method is None:
        method = detect_install_method()
    return method in _PACKAGE_INSTALL_METHODS


def package_upgrade_command(
        method: str,
        which: Callable[[str], Optional[str]] = shutil.which) -> Optional[str]:
    """Return the package-manager upgrade command for ``method``, or None."""
    if method == "apt":
        return "sudo apt update && sudo apt upgrade gigamate gigamate-dkms"
    if method == "dnf":
        return "sudo dnf upgrade gigamate gigamate-dkms"
    if method == "zypper":
        return "sudo zypper update gigamate gigamate-dkms"
    if method == "pacman":
        return "sudo pacman -Syu gigamate gigamate-dkms"
    if method == "aur":
        if which("paru"):
            return "paru -Syu gigamate gigamate-dkms"
        if which("yay"):
            return "yay -Syu gigamate gigamate-dkms"
        return "paru -Syu gigamate gigamate-dkms"
    return None


def build_package_terminal_update_command(
        method: str,
        desktop: str = "",
        which: Callable[[str], Optional[str]] = shutil.which,
        detect: Optional[Callable[..., Optional[Tuple[str, str]]]] = None,
        env: Optional[Mapping[str, str]] = None) -> Optional[list]:
    """Argv opening the user's terminal running the package-manager upgrade."""
    cmd = package_upgrade_command(method, which=which)
    if not cmd:
        return None
    return _open_terminal_with(
        f"{cmd}; exec bash",
        desktop=desktop,
        which=which,
        detect=detect,
        env=env,
    )


_LEGACY_BIN_NAMES = (
    "gigamate",
    "gigamate-tray",
    "gigamate-center",
    "gigamate-dgpu-watch",
)
_LEGACY_UNIT_NAMES = (
    "gigamate.service",
    "gigamate-dgpu.service",
)
_LEGACY_DESKTOP_NAMES = (
    "gigamate.desktop",
    "gigamate-center.desktop",
)
_LEGACY_ICON_NAMES = (
    "gigamate.svg",
    "gigamate-nvidia.svg",
    "gigamate-amd.svg",
    "gigamate-update.svg",
    "gigamate-nvidia-update.svg",
    "gigamate-amd-update.svg",
    "checkbox-checked.svg",
)
_PIP_CONSOLE_SCRIPT_RE = re.compile(
    r"\b(?:from|import)\s+gigamate\b|load_entry_point\(\s*['\"]gigamate\b"
)


def _is_legacy_pip_script(text: str) -> bool:
    """True when ``text`` looks like a pip/setuptools gigamate console script."""
    first_line = text.splitlines()[0] if text else ""
    return (
        first_line.startswith("#!")
        and "python" in first_line.lower()
        and bool(_PIP_CONSOLE_SCRIPT_RE.search(text))
    )


def migrate_legacy_user_install(
        home: Optional[Path] = None,
        state_file: Path = STATE_FILE,
        marker_path: Path = INSTALL_METHOD_FILE,
        run: Callable = subprocess.run,
        which: Callable[[str], Optional[str]] = shutil.which,
        system_share_dir: Path = Path("/usr/share")) -> list[str]:
    """One-time cleanup of legacy install.sh user files on packaged installs.

    No-op for script-managed installs or once ``migrated_to_pkg`` is persisted
    in ``state_file``. Preserves user configuration under ``~/.config/gigamate``
    and any custom scripts, desktop overrides, icons, or systemd units that do
    not match install.sh signatures or packaged files. Never raises on OSError.
    """
    if load_state(state_file).get("migrated_to_pkg"):
        return []
    method = detect_install_method(
        marker_path=marker_path, which=which, run=run
    )
    if not is_package_managed(method):
        return []

    user_home = home if home is not None else Path.home()
    removed: list[str] = []
    removed_unit = False

    bin_dir = user_home / ".local" / "bin"
    for name in _LEGACY_BIN_NAMES:
        path = bin_dir / name
        try:
            if not path.is_file():
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            if _is_legacy_pip_script(text):
                path.unlink()
                removed.append(str(path))
        except OSError:
            continue

    unit_dir = user_home / ".config" / "systemd" / "user"
    wants_dir = unit_dir / "graphical-session.target.wants"
    for name in _LEGACY_UNIT_NAMES:
        path = unit_dir / name
        try:
            if not path.is_file():
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            if ".local/bin/gigamate" in text:
                unit_resolved = path.resolve(strict=False)
                path.unlink()
                removed.append(str(path))
                removed_unit = True
                wants_link = wants_dir / name
                try:
                    if wants_link.is_symlink() and (
                        wants_link.resolve(strict=False) == unit_resolved
                        or not wants_link.exists()
                    ):
                        wants_link.unlink()
                        removed.append(str(wants_link))
                except OSError:
                    pass
        except OSError:
            continue

    apps_dir = user_home / ".local" / "share" / "applications"
    sys_apps_dir = system_share_dir / "applications"
    for name in _LEGACY_DESKTOP_NAMES:
        path = apps_dir / name
        try:
            if not (path.is_file() and not path.is_symlink()):
                continue
            pkg_desktop = sys_apps_dir / name
            matches_pkg = (
                pkg_desktop.is_file()
                and path.read_bytes() == pkg_desktop.read_bytes()
            )
            matches_legacy = False
            if not matches_pkg:
                text = path.read_text(encoding="utf-8", errors="replace")
                matches_legacy = (
                    "StartupWMClass=gigamate-center" in text
                    and ".local/bin/gigamate" in text
                )
            if matches_pkg or matches_legacy:
                path.unlink()
                removed.append(str(path))
        except OSError:
            continue

    icons_dir = (
        user_home / ".local" / "share" / "icons" / "hicolor" / "scalable" / "apps"
    )
    sys_icons_dir = (
        system_share_dir / "icons" / "hicolor" / "scalable" / "apps"
    )
    for name in _LEGACY_ICON_NAMES:
        path = icons_dir / name
        try:
            if not (path.is_file() and not path.is_symlink()):
                continue
            pkg_icon = sys_icons_dir / name
            if pkg_icon.is_file() and path.read_bytes() == pkg_icon.read_bytes():
                path.unlink()
                removed.append(str(path))
        except OSError:
            continue

    if removed_unit:
        try:
            if which("systemctl"):
                run(
                    ["systemctl", "--user", "daemon-reload"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=5,
                )
        except Exception:
            pass

    try:
        def _mark_migrated(state: Dict) -> Dict:
            state["migrated_to_pkg"] = True
            return state

        update_update_state(_mark_migrated, state_file=state_file)
    except OSError:
        pass

    return removed


def install_script_url(tag: Optional[str] = None) -> str:
    """Return the install.sh URL pinned to a release tag.

    Falls back to ``main`` only when no valid tag is known (e.g. a repo with
    no releases yet); callers should pass a discovered ``vX.Y.Z`` tag.
    """
    ref = (tag or "").strip()
    if not is_valid_tag(ref):
        ref = "main"
    return f"https://raw.githubusercontent.com/{REPO}/{ref}/install.sh"


def install_script_sha256_url(tag: Optional[str] = None) -> str:
    """Release-asset URL for the install.sh checksum (published by CI)."""
    ref = (tag or "").strip()
    if not is_valid_tag(ref):
        return ""
    return f"https://github.com/{REPO}/releases/download/{ref}/install.sh.sha256"


def _pinned_ref() -> str:
    """Best-known release tag from cached update state, else ``main``."""
    try:
        tag = load_state().get("latest_known")
    except Exception:
        tag = None
    return tag if isinstance(tag, str) and is_valid_tag(tag) else "main"


def _download_verify_run(url: str, extra_args: str,
                         sha_url: Optional[str] = None) -> str:
    """Shell snippet: download (fail on HTTP error), verify, then run.

    The download never pipes straight into a shell: it is written to a temp
    file, the published ``install.sh.sha256`` release asset is verified when
    available, and only then executed with ``bash``. Privileged steps inside
    install.sh elevate individually, so the updater itself must not run as
    root (that would break the user-level pip/systemd steps).
    """
    q_url = shlex.quote(url)
    q_sha = shlex.quote(sha_url or "")
    verify = (
        f'if [ -n {q_sha} ] && curl -fL --proto "=https" -o "$tmp.sha256" {q_sha} 2>/dev/null; then '
        '  expected="$(cut -d " " -f1 "$tmp.sha256" | head -n1)"; '
        '  actual="$(sha256sum "$tmp" | cut -d " " -f1)"; '
        '  if [ -z "$expected" ] || [ "$expected" != "$actual" ]; then '
        '    echo "install.sh checksum verification FAILED" >&2; '
        '    rm -f "$tmp" "$tmp.sha256"; ok=0; '
        '  else '
        '    echo "Verified install.sh checksum."; '
        '  fi; '
        'else '
        '  echo "WARNING: no checksum available for install.sh; proceeding unverified." >&2; '
        'fi; '
    )
    return (
        'tmp="$(mktemp)"; '
        'ok=1; '
        'rc=1; '
        f'if [ -z "$tmp" ] || ! curl -fL --proto "=https" -o "$tmp" {q_url}; then '
        '  echo "Failed to download install.sh" >&2; rm -f "$tmp"; ok=0; fi; '
        'if [ "$ok" = 1 ]; then '
        + verify +
        '  if [ "$ok" = 1 ]; then '
        f'    bash "$tmp" {extra_args}; rc=$?; '
        '  fi; '
        'fi; '
        'rm -f "$tmp" "$tmp.sha256"'
    )


def manual_update_instructions(tag: Optional[str] = None) -> str:
    """Checksum-verified, no-pipe update command for an administrator."""
    ref = tag or _pinned_ref()
    q_url = shlex.quote(install_script_url(ref))
    q_sha = shlex.quote(install_script_sha256_url(ref))
    return (
        "Ask an administrator to run this in a terminal:\n"
        "  tmp=\"$(mktemp /tmp/gigamate-install.XXXXXX.sh)\"\n"
        f"  curl -fL --proto \"=https\" --max-time 60 {q_url} -o \"$tmp\" || "
        "{ echo 'download failed'; rm -f \"$tmp\"; exit 1; }\n"
        f"  if curl -fL --proto \"=https\" --max-time 30 {q_sha} -o \"$tmp.sha256\" 2>/dev/null; then\n"
        "    [ \"$(sha256sum \"$tmp\" | cut -d' ' -f1)\" = "
        "\"$(cut -d' ' -f1 \"$tmp.sha256\")\" ] || "
        "{ echo 'install.sh checksum FAILED'; exit 1; }\n"
        "  else echo 'WARNING: no checksum available; proceeding unverified'; fi\n"
        f"  bash \"$tmp\" --update --tag {shlex.quote(ref)}"
    )



def _capture_stdout(argv: list, timeout: int = 10,
                    run: Callable = subprocess.run) -> Optional[str]:
    """Run argv, return stripped stdout on exit 0, else None. Never raises."""
    try:
        proc = run(argv, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                   timeout=timeout, text=True)
    except Exception:
        return None
    try:
        if proc.returncode == 0 and proc.stdout:
            return proc.stdout.strip() or None
    except Exception:
        pass
    return None


def _desktop_exec_arg(app_dirs: list, name: str) -> Optional[str]:
    """Read X-TerminalArgExec for a terminal from .desktop files."""
    name = (name or "").lower()
    if not name:
        return None
    for app_dir in app_dirs:
        try:
            files = sorted(Path(app_dir).glob("*.desktop"))
        except OSError:
            continue
        for entry in files:
            try:
                text = entry.read_text()
            except OSError:
                continue
            keys: Dict[str, str] = {}
            for line in text.splitlines():
                if not line or line[0] in ("[", "#", " ", "\t"):
                    continue
                if "=" not in line:
                    continue
                key, val = line.split("=", 1)
                keys[key.strip()] = val.strip().strip('"')
            candidates = set()
            for raw in (keys.get("TryExec", ""), keys.get("Exec", "")):
                if not raw:
                    continue
                try:
                    first = shlex.split(raw)[0]
                except Exception:
                    first = raw.split()[0] if raw.split() else ""
                if first:
                    candidates.add(os.path.basename(first).lower())
            stem = entry.stem.lower()
            if name in candidates or name in stem or stem in name:
                return keys.get("X-TerminalArgExec", "-e") or "-e"
    return None


def detect_default_terminal(
        env: Optional[Mapping[str, str]] = None,
        run: Callable = subprocess.run,
        which: Callable[[str], Optional[str]] = shutil.which,
        app_dirs: Optional[list] = None) -> Optional[Tuple[str, str]]:
    """Detect the user's default terminal → (binary, exec_arg) or None.

    Order: KDE setting → GNOME setting → $TERMINAL → Debian
    alternatives. The exec flag comes from the terminal's own .desktop
    entry (X-TerminalArgExec), defaulting to ``-e``. gi-free; everything
    injectable for tests. Never raises.
    """
    env = os.environ if env is None else env
    if app_dirs is None:
        home = env.get("HOME", str(Path.home()))
        app_dirs = [Path(home) / ".local" / "share" / "applications",
                    Path("/usr/share/applications")]
    desktop = (env.get("XDG_CURRENT_DESKTOP", "") or "").lower()
    name: Optional[str] = None

    try:
        if "kde" in desktop or "plasma" in desktop:
            out = _capture_stdout(
                ["kreadconfig6", "--file", "kdeglobals",
                 "--group", "General", "--key", "TerminalApplication"],
                run=run)
            if out:
                name = out.split()[0]
        elif "gnome" in desktop or "unity" in desktop or "cinnamon" in desktop:
            out = _capture_stdout(
                ["gsettings", "get",
                 "org.gnome.desktop.default-applications.terminal", "exec"],
                run=run)
            if out:
                name = out.strip().strip("'\"").split()[0]
    except Exception:
        pass
    if not name and env.get("TERMINAL"):
        name = env["TERMINAL"].split()[0]
    if not name:
        out = _capture_stdout(
            ["update-alternatives", "--query", "x-terminal-emulator"],
            run=run)
        if out:
            for line in out.splitlines():
                if line.startswith("Value:"):
                    name = line.split(":", 1)[1].strip().split()[0]
                    break
    if not name:
        return None
    binary = which(name) or (name if "/" in name else None)
    if not binary:
        return None
    short = os.path.basename(binary).lower()
    exec_arg = _desktop_exec_arg(app_dirs, short) or "-e"
    return binary, exec_arg


# Terminals needing `--` before the command (gnome-terminal family).
_DASHDASH_TERMINALS = frozenset({"gnome-terminal", "mate-terminal", "ptyxis"})


def _terminal_argv(binary: str, exec_arg: str, inner: str) -> list:
    """Build [terminal … bash -c inner], honouring `--` families."""
    if os.path.basename(binary).lower() in _DASHDASH_TERMINALS:
        return [binary, "--", "bash", "-c", inner]
    return [binary, exec_arg, "bash", "-c", inner]


def _default_detect(env: Optional[Mapping[str, str]],
                    which: Callable[[str], Optional[str]]
                    ) -> Optional[Tuple[str, str]]:
    return detect_default_terminal(env=env, which=which)


def build_terminal_update_command(
        desktop: str = "",
        which: Callable[[str], Optional[str]] = shutil.which,
        detect: Optional[Callable[..., Optional[Tuple[str, str]]]] = None,
        env: Optional[Mapping[str, str]] = None,
        tag: Optional[str] = None) -> Optional[list]:
    """Argv opening the user's terminal running the update, else None.

    Prefers the desktop's configured default terminal (KDE/GNOME/$TERMINAL/
    alternatives + its own X-TerminalArgExec flag), then scans common
    emulators. The update runs inside with the shell kept afterwards so
    output stays visible.
    """
    ref = tag or _pinned_ref()
    snippet = _download_verify_run(
        install_script_url(ref), f"--update --yes --tag {shlex.quote(ref)}",
        sha_url=install_script_sha256_url(ref) or None)
    return _open_terminal_with(f"{snippet}; exec bash",
                               desktop=desktop, which=which,
                               detect=detect, env=env)


def _open_terminal_with(
        inner: str,
        desktop: str = "",
        which: Callable[[str], Optional[str]] = shutil.which,
        detect: Optional[Callable[..., Optional[Tuple[str, str]]]] = None,
        env: Optional[Mapping[str, str]] = None) -> Optional[list]:
    """Argv opening the user's terminal running ``inner``, else None.

    Prefers the desktop's configured default terminal (KDE/GNOME/$TERMINAL/
    alternatives + its own X-TerminalArgExec flag), then scans common
    emulators. The shell is kept afterwards so output stays visible.
    """
    detect_fn = detect if detect is not None else (
        lambda: _default_detect(env, which))
    try:
        found = detect_fn()
    except Exception:
        found = None
    if found:
        binary, exec_arg = found
        return _terminal_argv(binary, exec_arg, inner)
    candidates = [
        ("ghostty", "-e"),
        ("kitty", "-e"),
        ("alacritty", "-e"),
        ("ptyxis", "--"),
        ("kgx", "-e"),
        ("konsole", "-e"),
        ("gnome-terminal", "--"),
        ("xfce4-terminal", "-e"),
        ("wezterm", "-e"),
        ("foot", None),  # positional command, no flag
        ("qterminal", "-e"),
        ("mate-terminal", "--"),
        ("lxterminal", "-e"),
        ("x-terminal-emulator", "-e"),
        ("xterm", "-e"),
    ]
    desktop = (desktop or "").lower()
    desktop_terminal = {
        "gnome": "gnome-terminal",
        "kde": "konsole",
        "plasma": "konsole",
        "xfce": "xfce4-terminal",
        "lxde": "lxterminal",
        "lxqt": "lxterminal",
    }
    preferred = desktop_terminal.get(desktop)
    ordered = sorted(candidates,
                     key=lambda c: (c[0] != preferred, c[0] not in desktop))
    for term, flag in ordered:
        binary = which(term)
        if not binary:
            continue
        if flag is None:
            return [binary, "bash", "-c", inner]
        return _terminal_argv(binary, flag, inner)
    return None


def menu_item_label(update_available: bool) -> str:
    """Label for the single update menu entry.

    Morphs between idle and available states so there is exactly one
    entry point. Kept version-free on purpose; the confirm dialog shows
    the exact versions.
    """
    return "Update available" if update_available else "Check for updates"


def build_update_command(log_file: Path = UPDATE_LOG_FILE,
                         tag: Optional[str] = None) -> list:
    """Argv the tray spawns in background to self-update non-interactively.

    Output goes to ``log_file`` so silent background failures stay
    diagnosable (the tray shows the path when the updater exits non-zero).
    """
    ref = tag or _pinned_ref()
    snippet = _download_verify_run(
        install_script_url(ref), f"--update --yes --tag {shlex.quote(ref)}",
        sha_url=install_script_sha256_url(ref) or None)
    log_q = shlex.quote(str(log_file))
    inner = f"{{ {snippet}; exit $rc; }} >{log_q} 2>&1"
    return _detached_update_argv(inner)


def _detached_update_argv(inner: str) -> list:
    """Wrap the updater so it survives the tray-service restart.

    install.sh restarts ``gigamate.service`` (which spawns the updater), and
    systemd's default ``KillMode=control-group`` SIGTERMs every process in that
    cgroup — including the updater, so the tray reports a spurious "Updater
    exited with status 15" even though the install succeeded. Running the
    updater in its own transient scope places it in a separate cgroup, so the
    restart cannot kill it. Falls back to a plain shell when ``systemd-run`` is
    unavailable.
    """
    if shutil.which("systemd-run"):
        return ["systemd-run", "--user", "--scope", "--collect", "--",
                "bash", "-c", inner]
    return ["bash", "-c", inner]


REPAIR_HELPER_PATH = "/usr/lib/gigamate/gigamate-repair"


def repair_available() -> bool:
    """True when the privileged ACPI repair helper is installed and reachable."""
    return os.path.exists(REPAIR_HELPER_PATH) and shutil.which("pkexec") is not None


def repair_command() -> Optional[list]:
    """Argv to run the privileged repair helper (None when not available)."""
    if repair_available():
        return ["pkexec", REPAIR_HELPER_PATH]
    return None


def terminal_repair_snippet() -> str:
    """Privileged repair commands for a terminal when the helper is missing.

    Rebuilds + reloads ``gigamate_acpi`` for the running kernel via DKMS,
    handling the stale-registration case, prunes stale DKMS registrations
    (keeping versions that still cover a live kernel), then loads the module.
    Requires sudo (prompts in the terminal).
    """
    return (
        'v="$(ls -d /usr/src/gigamate_acpi-* 2>/dev/null | sort -V | tail -1'
        ' | sed "s#.*gigamate_acpi-##")"; '
        '[ -n "$v" ] || { echo "No gigamate_acpi source under /usr/src"; exit 1; }; '
        'sudo dkms add -m gigamate_acpi -v "$v" 2>/dev/null || true; '
        'sudo dkms install -m gigamate_acpi -v "$v" -k "$(uname -r)" --force || '
        'sudo env CC=clang LLVM=1 dkms install -m gigamate_acpi -v "$v" -k "$(uname -r)" --force || '
        '{ echo "DKMS build failed — install kernel headers for $(uname -r)"; exit 1; }; '
        'for old in $(ls /var/lib/dkms/gigamate_acpi 2>/dev/null | grep -v "^kernel-"); do '
        '[ "$old" = "$v" ] && continue; '
        'keep=0; '
        'for l in /var/lib/dkms/gigamate_acpi/kernel-*; do '
        '[ -L "$l" ] || continue; '
        'k="${l##*/}"; k="${k#kernel-}"; k="${k%-*}"; '
        '[ -d "/lib/modules/$k" ] || continue; '
        't="$(readlink "$l" 2>/dev/null)"; '
        't="${t#/var/lib/dkms/gigamate_acpi/}"; '
        't="${t%%/*}"; '
        '[ "$t" = "$old" ] && keep=1; '
        'done; '
        '[ "$keep" = 1 ] || { sudo dkms remove "gigamate_acpi/$old" --all 2>/dev/null && '
        'sudo rm -rf "/usr/src/gigamate_acpi-$old" 2>/dev/null; }; '
        'done; '
        'sudo depmod -a; '
        'sudo modprobe -r gigamate_acpi 2>/dev/null || true; '
        'sudo modprobe gigamate_acpi && echo "GigaMate ACPI driver repaired."'
    )


def build_terminal_repair_command(
        desktop: str = "",
        which: Callable[[str], Optional[str]] = shutil.which,
        detect: Optional[Callable[..., Optional[Tuple[str, str]]]] = None,
        env: Optional[Mapping[str, str]] = None) -> Optional[list]:
    """Argv opening the user's terminal running the privileged repair commands."""
    return _open_terminal_with(
        f"{terminal_repair_snippet()}; exec bash",
        desktop=desktop, which=which, detect=detect, env=env)
